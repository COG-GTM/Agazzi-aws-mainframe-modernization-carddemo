       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.    SDSF.                                                 
       AUTHOR.        AWS.                                                      
                                                                                
       ENVIRONMENT DIVISION.                                                    
       INPUT-OUTPUT SECTION.                                                    
      *                                                                         
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
       WORKING-STORAGE SECTION.                                                 
      *****************************************************************         
       PROCEDURE DIVISION.                                                      
           DISPLAY 'DUMMY PROGRAM FOR SDSF'.                    
           GOBACK.                                                              
                                                                                
